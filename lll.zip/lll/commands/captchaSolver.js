// captchaSolver.js

const axios = require("axios");

// Function to solve the CAPTCHA
async function solve(captchaSolution, apiKey) {
    try {
        // Make a request to your CAPTCHA solving service/API
        const response = await axios.post("8ca250ae-6491-4379-adda-f124851a60c7", {
            captchaSolution: captchaSolution
            // Add any additional parameters required by your API
        }, {
            headers: {
                "Authorization": `Bearer ${apiKey}`
                // Add other headers as needed
            }
        });

        // Check if the request was successful
        if (response.status === 200) {
            // Assuming your API returns data in JSON format with a "success" field
            return response.data;
        } else {
            // If the request fails, return an error
            return { success: false, error: "CAPTCHA solving service error" };
        }
    } catch (error) {
        // If an error occurs during the request, return an error
        return { success: false, error: error.message };
    }
}

module.exports = { solve };
