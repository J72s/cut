const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Clear the queue
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        // Send a message to indicate queue clearing
        client.channels.cache.get('1240050863007862815').send(`Clearing queue, command from ${message.guild.name}`);

        // Get the server queue
        const serverQueue = queue.get("queue");

        // If there is a server queue and it has songs, keep only the first song
        if (serverQueue && serverQueue.songs) {
            serverQueue.songs = [serverQueue.songs[0]];
        }

        // Send a confirmation message
        message.channel.send('🧹 Queue cleared !');
    } catch (error) {
        // Log the error
        console.error("Error occurred while clearing queue:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while clearing queue:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorClearingQueue);
    }
};

module.exports.names = {
    list: ["clear"]
};
