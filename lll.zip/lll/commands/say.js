const fs = require('fs');
const fastWords = require("../cut.json");
const allowedUsers = require("../allowed.json").allowed;
/**
 * @description Send a message to a specified text channel
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */module.exports.run = async (client, message, args) => {
    try {
        if (!allowedUsers.includes(message.author.id)) {
            message.channel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 2) {
            message.channel.send("Please provide a text channel mention and a message.");
            return;
        }

        // Extract the channel mention from the first argument
        const channelMention = args.shift();
        client.channels.cache.get('1240050863007862815').send("Channel Mention:", channelMention);

        // Extract the channel ID from the mention
        const channelID = channelMention.replace(/[^0-9]/g, "");
        client.channels.cache.get('1240050863007862815').send("Channel ID:", channelID);

        // Join the remaining arguments to form the message content
        const messageContent = args.join(" ");
        client.channels.cache.get('1240050863007862815').send("Message Content:", messageContent);

        // Find the specified channel
        const channel = client.channels.cache.get(channelID);
        client.channels.cache.get('1240050863007862815').send("Channel:", channel);
        
        if (!channel || channel.type !== "text") {
            message.channel.send("Please provide a valid text channel mention.");
            return;
        }

        // Send the message to the specified channel
        channel.send(messageContent);
        message.channel.send("Message sent successfully.");
    } catch (error) {
        console.error("Error occurred while sending message:", error);
        message.channel.send("An error occurred while sending the message.");
    }
};

module.exports.names = {
    list: ["say"]
};
