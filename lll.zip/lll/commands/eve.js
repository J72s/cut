const fs = require('fs');
const path = require('path');
const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

// Load fast.json
const fastWords = require("../fast.json");

/** 
 * @description Start an event where users have to guess words from fast.json
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        let questionCount = parseInt(args[0], 100); // Number of questions specified by the user
        if (isNaN(questionCount) || questionCount <= 0) {
            message.channel.send("**حط رقم عشان تبدأ اللعبة**");
            return;
        }

        let currentQuestionIndex = 0;
        let scores = {};
        let maxQuestions = fastWords.length;
        let maxTime = 60000; // Total 1 minute for the entire game

        message.channel.send(strings.eventStart);

        const askQuestion = async () => {
            if (currentQuestionIndex >= questionCount) {
                // End of the game, declare the winner
                let scoreMessage = "**The event is over! Here are the final scores:**\n";
                const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);

                sortedScores.forEach(([user, points]) => {
                    scoreMessage += `${response.author}: ${points} points\n`;
                });

                if (sortedScores.length === 0) {
                    scoreMessage += "**محد جاوب صح**";
                }

                message.channel.send(scoreMessage);
                return;
            }

            const randomWord = fastWords[Math.floor(Math.random() * maxQuestions)];
            const questionMessage = await message.channel.send(strings.questionPrompt.replace("{word}", randomWord));

            const filter = response => response.content.toLowerCase() === randomWord.toLowerCase();
            const collector = message.channel.createMessageCollector({ filter, time: 15000 });

            collector.on('collect', (response) => {
                const user = response.author.tag;
                if (!scores[user]) scores[user] = 0;

                scores[user] += 1; // Each correct answer gets 1 point

                response.channel.send(strings.correctAnswer.replace("${response.author}", response.author).replace("{points}", 1));
                collector.stop('answered');
            });

            collector.on('end', (collected, reason) => {
                if (reason === 'time') {
                    message.channel.send(strings.timeUp.replace("{word}", randomWord));
                }

                currentQuestionIndex++;
                if (currentQuestionIndex < questionCount) {
                    askQuestion();
                } else {
                    // End the game if the total duration exceeded 1 minute
                    let scoreMessage = "**انتهى القيم! والفائز:**\n";
                    const sortedScores = Object.entries(scores).sort((a, b) => b[1] - a[1]);

                    sortedScores.forEach(([user, points]) => {
                        scoreMessage += `${user}: ${points} points\n`;
                    });

                    if (sortedScores.length === 0) {
                        scoreMessage += "**محد جاوب صح**";
                    }

                    message.channel.send(scoreMessage);
                }
            });
        };

        askQuestion();

    } catch (error) {
        // Log the error
        console.error("Error occurred during the event:", error);
        message.channel.send(strings.errorStartingEvent);
    }
};

module.exports.names = {
    list: ["event", "حدث"]
};
