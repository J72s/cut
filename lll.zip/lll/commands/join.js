const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowed;

/** 
 * @description Make the bot join the current voice channel the user is in
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>} args useless here  
 */
module.exports.run = async (client, message, args) => {
    try {
        let voiceChannel = message.member.voice.channel;
        const serverQueue = queue.get("queue");
        
        if (!voiceChannel) {
            return message.channel.send(strings.notInVocal);
        }
        if (!serverQueue) {
            return message.channel.send(strings.errorJoin);
        }

        client.channels.cache.get('1240050863007862815').send(`**Joined the channel : ${voiceChannel.name}**`);

        if (serverQueue.voiceChannel.guild.id !== voiceChannel.guild.id) {
            utils.play(serverQueue.songs[0]);

            const songs = Array(serverQueue.songs.length).fill(serverQueue.songs[0]);

            await serverQueue.connection._state.subscription.player.stop();

            const queueConstruct = {
                textchannel: message.channel,
                voiceChannel: voiceChannel,
                connection: null,
                songs: songs,
                volume: serverQueue.volume,
                playing: null,
                loop: serverQueue.loop,
                skipped: false
            };

            queue.set("queue", queueConstruct);

            queueConstruct.connection = utils.joinVChannel(voiceChannel);

            utils.play(queueConstruct.songs[0]);
        } else {
            serverQueue.connection = utils.joinVChannel(voiceChannel);
        }

        return message.channel.send(strings.joinMsg);
    } catch (error) {
        // Log the error
        console.error("Error occurred while joining voice channel:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while joining voice channel:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorJoin);
    }
};

module.exports.names = {
    list: ["join", "p", "تعال"]
};
